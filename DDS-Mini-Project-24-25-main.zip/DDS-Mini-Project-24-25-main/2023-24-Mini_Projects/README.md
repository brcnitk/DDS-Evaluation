# DDS-Mini-Project-23-24
Design of Digital Systems (DDS) course Mini-Project (Academic Year: 2023-24) details ...

## List:

| Sl. No. | Title | Title |
| :---: | --- | --- |
| 1 | [(Detail)]() | Universal Asynchronous Receiver-Transmitter [(Detail)]() |
| 2 | Smart Bicycle [(Detail)](https://github.com/brcnitk/DDS-Mini-Project-24-25/blob/main/2023-24-Mini_Projects/Snapshots/AmruthSD_Smart-Bicycle.pdf) | Heatwatch: Temperature Monitoring System [(Detail)]() |
| 3 | [(Detail)]() | Braille-to-Audio Converter [(Detail)]() |
| 4 | Agri Rain Alarm System [(Detail)]() | Automated Braking System [(Detail)]() |
| 5 | TrainGuard: Empowering Ticket Collectors with Smart Passenger Monitoring [(Detail)]() | Tic Tac Toe Game [(Detail)]() |
| 6 | Line Following Maze Solver [(Detail)]() | Vending Machine for cold and Hot beverages [(Detail)]() |
| 7 | Secure Vote: Digital Voting Machine [(Detail)]() | eX_Calci [(Detail)]() |
| 8 | Automatic Visitor Counter and Power Control [(Detail)]() | Smart Home Energy Monitoring and Management System [(Detail)]() |
| 9 | Parking Management System [(Detail)]() | Automated Reception Desk for Hospitals [(Detail)]() |
| 10 | Memory Game [(Detail)]() | Guaranteed Profits with Arbitrage Betting [(Detail)]() |
| 11 | End To End Encryption [(Detail)]() | Text to Braille Converter [(Detail)]() |
| 12 | Enhanced Security Locking System [(Detail)]() | Auto Sensing Fire Extinguisher [(Detail)]() |
| 13 | Alcohol Detection with Vehicle Controlling System [(Detail)]() | Smart Commute [(Detail)]() |
| 14 | Digital Clock [(Detail)]() | Patient Friendly Medication Digital Reminder System [(Detail)]() |
| 15 | Vacant Parking SLot Detector [(Detail)]() | Digit Number Lock System [(Detail)]() |
| 16 | Dual Dice Game [(Detail)]() | Optimum room temperature regulator [(Detail)]() |
| 17 | Railway Traffic Management [(Detail)]() |  Binary Arcade: A Digital Binary Game [(Detail)]() |
| 18 | Small Scale DES Algorithm [(Detail)]() | Smart Home Automation System [(Detail)]() |
| 19 | Water Level Indicator [(Detail)]() | The Chess Clock [(Detail)]() |
| 20 | Automated Sensory Based Waste Segregation System [(Detail)]() | Hydrosure [(Detail)]() |
| 21 | Digital Combination Lock [(Detail)]() | Smart Ring with Body Vital Sensors [(Detail)]() |
| 22 | Traffic Light Controller: Intersection of a busy road and a street road) [(Detail)]() | Elevator Scheduling and Controlling System [(Detail)]() |
| 23 | LED Catcher - A Game of Reflexes [(Detail)]() | Car Parking Lot Ticket System [(Detail)]() |
